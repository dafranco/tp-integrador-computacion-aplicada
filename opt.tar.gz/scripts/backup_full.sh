#!/bin/bash

# Inicializar variables
origen=""
backup_dir=""
# Función para mostrar la ayuda
mostrar_ayuda() {
    echo "Uso: $0 -origen <archivo_origen> [-h]"
    echo
    echo "Opciones:"
    echo "  -origen     Especifica el nombre del directorio de origen."
    echo "  -destino     Especifica el nombre del directorio destino."
    echo "  -h          Muestra esta ayuda."
    exit 0
}

verificar_mount_point() {
  if ! mountpoint -q "$1"; then
      echo "Error: El directorio destino '$1' no existe o no está montado."
      exit 1
  fi

}

# Analizar argumentos
while [[ "$#" -gt 0 ]]; do
    case $1 in
        -origen) origen="$2"; shift ;;
        -destino) backup_dir="$2"; shift ;;
        -h) mostrar_ayuda ;;
        *) echo "Argumento desconocido: $1"; mostrar_ayuda ;;
    esac
    shift
done

# Verificar que el parámetro origen se ha proporcionado
if [ -z "$origen" ] || [ -z "$backup_dir" ]; then
    echo "Debe proporcionar el parámetro: -origen y -destino"
    mostrar_ayuda
fi

# Verificar que el directorio origen exista
if ! [[ -d "$origen" ]]; then
    echo "El archivo $origen no existe."
    exit 1
fi

# Verificar que el directorio destino exista y esté montado
verificar_mount_point $backup_dir

# Comprimir directorio
nombre_destino="$(date +%Y%m%d)$(echo "$origen" | sed 's/\//_/g').tar.gz"
echo $nombre_destino
tar -cvzf $nombre_destino -C $origen .
mv ./$nombre_destino $backup_dir

echo "backup generado con éxito en $backup_dir/$nombre_destino"
exit 0

